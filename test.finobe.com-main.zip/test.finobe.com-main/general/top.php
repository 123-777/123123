<?php
include($_SERVER['DOCUMENT_ROOT'] . '/general/loadingValues/generalConfigs.php');
?>
<title><?php echo $ProjectName; ?></title>
<link rel='stylesheet' href='<?php echo $baseUrl; ?>/general/css/app.php'>
<link rel='stylesheet' href='<?php echo $baseUrl; ?>/general/css/usetypekit.css'>
<link rel='stylesheet' href='<?php echo $baseUrl; ?>/general/css/fontawesome-pro-v5.10.1/css/all.css'>
<link rel='stylesheet' href='<?php echo $baseUrl; ?>/general/css/fontawesome-pro-v5.10.1/css/all.css'>
<script src="<?php echo $baseUrl; ?>/general/js/jquery-3.6.1.min.js" type="text/javascript"></script>
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
<meta http-equiv='X-UA-Compatible' content='IE=edge'>
<meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
<meta name='csrf-token' content='UoWWdpkURTTM6O5NFqC8YmUD3tQykALzti6x44z2'>
<meta name='og:title' content='<?php echo $ProjectName; ?>'>
<meta name='author' content='<?php echo $ProjectName; ?>'>
<meta name='description' content='<?php echo $ProjectName; ?>, it is website. He is for old brick-builder. Good for use.'>
<meta name='og:description' content='<?php echo $ProjectName; ?>, it is website. He is for old brick-builder. Good for use.'>
<meta name='og:site_name' content='<?php echo $ProjectName; ?>'>