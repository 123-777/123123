<?php
echo file_get_contents($_SERVER['DOCUMENT_ROOT'] . "/imgs/pending.gif");
?>